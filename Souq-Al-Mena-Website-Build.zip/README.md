# Souq Al Mena — Website Build

## Structure
- Main corporate site: `/`
- General Trading: `/trading/`
- Digital Marketing + E-commerce + Automation: `/digital-marketing/`
- Recruitment + Staffing + HR: `/recruitment/`
- Business Solutions: `/business-solutions/`
- Gardenia Irrigation Solutions: `/gardenia/`

## Deployment
This is a static HTML/CSS/JS build designed for Cloudflare Pages or Cloudflare Workers Static Assets.

### Cloudflare
Connect the GitHub repository or upload the project. No build command is required for the static version. Use the existing `www.souq-mena.com` domain for the main site.

For Gardenia, use the existing-domain subdomain:
`gardenia.souq-mena.com`
This does not require buying another domain.

## Forms
The contact and Gardenia quote forms currently use FormSubmit to deliver to `souqalmena@gmail.com`.
For production, you may replace the form endpoint with a preferred business-grade form/Cloudflare Worker/Google Apps Script endpoint.

## Stripe
The Gardenia catalogue is intentionally quote-first at launch. This avoids taking payment before supplier, stock, landed cost and delivery are confirmed.
When a product is operationally validated, add its Stripe Payment Link to its product card or connect a secure Stripe Checkout backend.

Do NOT place a Stripe secret key in browser JavaScript.

## Important business positioning
The website intentionally does not advertise landscaping, interior design or property snagging as Souq Al Mena corporate services. Those engagements were signed personally and are not stated as current licence activities.
