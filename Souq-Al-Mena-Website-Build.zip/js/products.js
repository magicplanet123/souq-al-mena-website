// Add Stripe Payment Links here only for products whose fulfilment, delivery and pricing are confirmed.
// Never add a Stripe secret key to front-end JavaScript.
const stripePaymentLinks = {};
